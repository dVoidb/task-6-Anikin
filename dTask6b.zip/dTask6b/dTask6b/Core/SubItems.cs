﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace dTask6b.Core
{
    internal class SubItems
    {
        public string Name { get; private set; }
        public UserControl UConrol { get; private set; }
        public SubItems(string name, UserControl uControl = null)
        {
            Name = name;
            UConrol = uControl;
        }
    }
}
